/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medeasy;

import database.connection.MySQL_Coonection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mdsad
 */
public class PushData {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        AddMedicine();
    }

    static void AddMedicine() throws SQLException, ClassNotFoundException {
        Connection connection;
        connection = MySQL_Coonection.getConnection();
        String s;
        int low = 50;
        int high = 200;
        for (int i = 0; i <= 1000; i++) {
            Random rand = new Random();

            int result = rand.nextInt(high - (low-2)) + low;
            System.err.println(" edtdfhghkhvjlhjkghf  "+result);
            if (i % 2 == 0) {
                s = "LEFT:ROOM-" + (result /2);
            } else {
                s = "RIGHT:ROOM-" +(result /2);
            }
            String query = "update drugs set priceOfEachPill='" + result /2 + "', direction='" + s + "' WHERE ID=" + i;
            System.err.println("query " + query);
            PreparedStatement ps1 = connection.prepareStatement(query);
            ps1.executeUpdate();

        }
    }

}
