package medeasy;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mdsad
 */
public class Bill {
    private int id,count,eachPillPrice,totalForEachMedicine;
    private String medicineName,Direction;

    public void setId(int id) {
        this.id = id;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setEachPillPrice(int eachPillPrice) {
        this.eachPillPrice = eachPillPrice;
    }

    public void setTotalForEachMedicine(int totalForEachMedicine) {
        this.totalForEachMedicine = totalForEachMedicine;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public void setDirection(String Direction) {
        this.Direction = Direction;
    }

    public int getId() {
        return id;
    }

    public int getCount() {
        return count;
    }

    public int getEachPillPrice() {
        return eachPillPrice;
    }

    public int getTotalForEachMedicine() {
        return totalForEachMedicine;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public String getDirection() {
        return Direction;
    }
    public Bill(int id,String medicineName,int count,int eachPillPrice,int totalForEachMedicine,String Direction)
    {
        this.id = id;
        this.medicineName = medicineName;
        this.count = count;
        this.eachPillPrice = eachPillPrice;
        this.totalForEachMedicine = totalForEachMedicine;
        this.Direction = Direction;
        
    }
    
}
