/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medeasy;

import ExportPDF.GeneratePdf;
import com.itextpdf.text.ListItem;
import com.sun.javafx.scene.control.skin.TextFieldSkin;
import database.connection.MySQL_Coonection;
import impl.org.controlsfx.skin.AutoCompletePopup;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import org.controlsfx.control.textfield.TextFields;

/**
 *
 * @author mdsad
 */
public class FXMLDocumentController implements Initializable {

    public static int tableId = 1;

    public static int DUMMY_PRICE_OF_EACH_PILLS = 8;

    @FXML
    private TextField IdOfPatient;

    @FXML
    private TextField IdOfDoctor;

    @FXML
    private Button IdOfPrint;

    @FXML
    private Button search_btn;
    @FXML
    private Label show_priceID;
    @FXML
    private TextField listOfMedicine;

    @FXML
    private TextField idOfMedNameTextViewInDirection;

    @FXML
    private TextField idOfDirectionTextView;

    @FXML
    private TextField idOfAddMedicineFromCount;

    @FXML
    private TextField idOfMedicineCount;

    @FXML
    private TableView<Bill> IdOf_View;

    @FXML
    private TableColumn<Bill, Integer> IdOfColumn_SerialNumber;

    @FXML
    private TableColumn<Bill, String> IdOfColumn_MedicineName;

    @FXML
    private TableColumn<Bill, Integer> IdOfColumn_Count;

    @FXML
    private TableColumn<Bill, Integer> IdOfColumn_EachPillPrice;

    @FXML
    private TableColumn<Bill, Integer> IdColumn_TotalForEachMedicine;

    @FXML
    private TableColumn<Bill, String> IdOfColumn_Direction;
    //ObservableList<Bill> list = FXCollections.observableArrayList();
    ArrayList<Bill> list = new ArrayList<>();
    // ArrayList<Patient> P_List = new ArrayList<>();

    public FXMLDocumentController() {
    }

    @FXML
    void Search_Medicine_BTN(ActionEvent event) throws SQLException, ClassNotFoundException {

        String medName = listOfMedicine.getText();
        System.err.println("name from ui:" + medName);
        String medicineDirection = null;
        Connection connect = MySQL_Coonection.getConnection();
        String query = "select * from drugs where medicine_name='" + medName.trim() + "'";
        System.err.println("query " + query);
        PreparedStatement ps1 = connect.prepareStatement(query);
        ResultSet rs1 = ps1.executeQuery();

        String medNameComingFromDb = null;
//        medNameComingFromDb = rs.getString("med_name");            
//            medicineDirection = rs.getString("directionOfmed"); 
        System.err.println("condition before entring into while loop:");
        while (rs1.next()) {

            medNameComingFromDb = rs1.getString("medicine_name");
            medicineDirection = rs1.getString("direction");
            System.err.println(medNameComingFromDb + "   " + medicineDirection);

        }
        idOfMedNameTextViewInDirection.setText(medNameComingFromDb);
        idOfDirectionTextView.setText(medicineDirection);
        idOfAddMedicineFromCount.setText(medNameComingFromDb);

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        Connection connection;

        List<String> popupdata = new ArrayList<>();
        try {
            connection = MySQL_Coonection.getConnection();
            PreparedStatement ps = connection.prepareStatement("select * from drugs limit 300");

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String data = rs.getString("medicine_name");
                popupdata.add(data);
            }

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        AutoCompletePopup<String> a = new AutoCompletePopup<>();

        TextFields.bindAutoCompletion(listOfMedicine, popupdata.toArray());
        IdOfColumn_SerialNumber.setCellValueFactory(new PropertyValueFactory<>("id"));
        IdOfColumn_MedicineName.setCellValueFactory(new PropertyValueFactory<>("medicineName"));
        IdOfColumn_Count.setCellValueFactory(new PropertyValueFactory<>("count"));
        IdOfColumn_EachPillPrice.setCellValueFactory(new PropertyValueFactory<>("eachPillPrice"));
        IdColumn_TotalForEachMedicine.setCellValueFactory(new PropertyValueFactory<>("totalForEachMedicine"));
        IdOfColumn_Direction.setCellValueFactory(new PropertyValueFactory<>("direction"));
    }

    @FXML
    void ActionOnAddMedicine(ActionEvent event) throws ClassNotFoundException, SQLException {
        DUMMY_PRICE_OF_EACH_PILLS = getEachPillPrice();
        int countOfMed = Integer.valueOf(idOfMedicineCount.getText());
        int priceOfTotalPills = countOfMed * DUMMY_PRICE_OF_EACH_PILLS;
        System.err.println(idOfAddMedicineFromCount.getText() + "   " + idOfMedicineCount.getText() + "  " + priceOfTotalPills);
        Bill b = new Bill(tableId, idOfAddMedicineFromCount.getText(), countOfMed, DUMMY_PRICE_OF_EACH_PILLS, priceOfTotalPills, idOfDirectionTextView.getText());
        ++tableId;
        list.add(b);
        listOfMedicine.clear();
        idOfAddMedicineFromCount.clear();
        idOfMedNameTextViewInDirection.clear();
        idOfDirectionTextView.clear();
        idOfMedicineCount.clear();

        System.err.println("item saved successfully:" + priceOfTotalPills);

    }

    @FXML
    void ActionOnGenerateBill(ActionEvent event) {
        float setTotalValue = 0;
        System.err.println("This is working");
        ObservableList<Bill> data = FXCollections.<Bill>observableArrayList(list);

        IdOf_View.setItems(data);

        for (int i = 0; i < list.size(); i++) {
            setTotalValue += list.get(i).getTotalForEachMedicine();
        }
        show_priceID.setText("₹  " + setTotalValue);
        float TotalPrice=setTotalValue;

        tableId = 0;
    }

    //things needs to do on tableId to refrece the data;
    private int getEachPillPrice() throws ClassNotFoundException, SQLException {
        int price = 0;
        Connection connect = MySQL_Coonection.getConnection();
        String query = "select * from drugs where medicine_name='" + idOfAddMedicineFromCount.getText() + "'";
        System.err.println("query " + query);
        PreparedStatement ps1 = connect.prepareStatement(query);
        ResultSet rs1 = ps1.executeQuery();

        while (rs1.next()) {

            price = rs1.getInt("priceOfEachPill");
        }
        return price;
    }

    @FXML
    void ActionOnPrint(ActionEvent event) {

        String PatientName = IdOfPatient.getText();
        String DoctorName = IdOfDoctor.getText();
        System.err.println("PatientNmae:--" + PatientName);
        System.err.println("DoctorNmae:--" + DoctorName);
        System.err.println("Action working");
        GeneratePdf.getSlipAsPdf(list, PatientName.toUpperCase(), DoctorName.toUpperCase());
        list.clear();
        IdOfPatient.clear();
        IdOfDoctor.clear();

    }
    
}
