/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bkwassthings;

/**
 *
 * @author mdsad
 */
public class AddressDetails {

    String buildName;
    double buildNum;
    String streetName;
    String city;
    String postCode;
    String country;

    public String getBuildName() {
        return buildName;
    }

    public void setBuildName(String buildName) {
        this.buildName = buildName;
    }

    public double getBuildNum() {
        return buildNum;
    }

    public void setBuildNum(double buildNum) {
        this.buildNum = buildNum;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public AddressDetails(String buildName, double buildNum, String streetName,
        String city, String postCode, String country) {
        this.buildName = buildName;
        this.buildNum = buildNum;
        this.streetName = streetName;
        this.city = city;
        this.postCode = postCode;
        this.country = country;
    }
}