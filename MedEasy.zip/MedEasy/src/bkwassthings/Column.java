/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bkwassthings;

/**
 *
 * @author mdsad
 */
public class Column<T> {
    private Class<T> type;
    private String fieldName;
    private String title;

    public Column(Class<T> type, String fieldName, String title) {
        this.type = type;
        this.fieldName = fieldName;
        this.title = title;
    }

    public Class<T> getType() {
        return type;
    }

    public void setType(Class<T> type) {
        this.type = type;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
