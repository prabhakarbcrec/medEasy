/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bkwassthings;
import bkwassthings.AddressDetails;
import java.util.*;
import javafx.application.Application;
import javafx.collections.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class AddressView extends Application {
    private static final String APPLICATION_TITLE = "Address List";

    public static final List<Column<?>> COLUMNS = new ArrayList<>(Arrays.asList(
        new Column<String>(String.class, "buildName", "Building Name"),
        new Column<Double>(Double.class, "buildNum", "Building Number"),
        new Column<String>(String.class, "streetName", "Street Name"),
        new Column<String>(String.class, "city", "City"),
        new Column<String>(String.class, "postCode", "Postcode"),
        new Column<String>(String.class, "country", "Country")
    ));
    
    private static List<AddressDetails> ADDRESS_LIST = new ArrayList<>(Arrays.asList(
        new AddressDetails("Building A", 1, "Street 1", "City X", "10101", "USA"),
        new AddressDetails("Building B", 2, "Street 2", "", "02020", "USA"),
        new AddressDetails("Building C", 3, "Street 3", "City X", "", "USA"),
        new AddressDetails(" D", 4, "Street 4", "City Y", "04040", "USA"),
        new AddressDetails("Building E", 5, "Street 5", "City X", "50505", "USA")
    ));

    @Override
    public void start(Stage primaryStage) throws Exception {
        StackPane root = new StackPane();
        TableView<AddressDetails> table = createTable(COLUMNS, ADDRESS_LIST);
        root.getChildren().add(table);
        primaryStage.setTitle(APPLICATION_TITLE);
        primaryStage.setScene(new Scene(root, 500, 200));
        primaryStage.show();
    }

    private <E> TableView<E> createTable(List<Column<?>> columns, List<E> data) {
        TableView<E> table = new TableView<>();
        ObservableList<E> addresses = FXCollections.observableArrayList(data);
        for (Column<?> column : columns) {
            table.getColumns().add(createColumn(column));
        }
        table.setItems(addresses);
        return table;
    }

    private <E, C> TableColumn<E, C> createColumn(Column<?> column, C type) {
        TableColumn<E, C> tableColumn = new TableColumn<E, C>(column.getTitle());
        tableColumn.setCellValueFactory(new PropertyValueFactory<E, C>(column.getFieldName()));
        return tableColumn;
    }

    private <E> TableColumn<E, ?> createColumn(Column<?> column) {
        switch (column.getType().getCanonicalName()) {
            case "java.lang.Integer":
                return createColumn(column, Integer.class);
            case "java.lang.Double":
                return createColumn(column, Double.class);
            case "java.lang.String":
            default:
                return createColumn(column, String.class);
        }
    }
    public static void main(String[] args) {
        launch(args);
    }
}
