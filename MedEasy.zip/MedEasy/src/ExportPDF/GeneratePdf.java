/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExportPDF;

//import medeasy.Patient;
import java.io.FileOutputStream;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.util.ArrayList;
import medeasy.Bill;
import com.itextpdf.text.Font;
import com.itextpdf.text.Rectangle;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author mdsad
 */
public class GeneratePdf {

//    private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18,
//            Font.BOLD);
//    private static Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,
//            Font.NORMAL, BaseColor.RED);
//    private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 16,
//            Font.BOLD);
//    private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12,
//            Font.BOLD);

    public static void getSlipAsPdf(ArrayList<Bill> data, String patientName, String doctorName) {
        try {
//..............................................................................................
            Paragraph paragraphOfAddress = new Paragraph();
            Paragraph paragraph2For_TableSpace = new Paragraph();
            Paragraph paragraphFor_HeadingSpace = new Paragraph();
            Paragraph paragraphFor_Date_and_Time = new Paragraph();
            Paragraph paagraphWhichWillStoreDoctoreAndPatientName = new Paragraph();
            paagraphWhichWillStoreDoctoreAndPatientName.add("\n\n DOCTOR-NAME: " + doctorName + "\n\n PATIENT-NAME: " + patientName);
            paragraphFor_Date_and_Time.setAlignment(Element.ALIGN_RIGHT);
           

            paragraphFor_HeadingSpace.add(" ");
            paragraphFor_HeadingSpace.setSpacingAfter(10f);
            paragraph2For_TableSpace.add(" ");
            paragraph2For_TableSpace.setSpacingAfter(10f);
            paragraphOfAddress.add("                                                       Baheri  Darbhanga Pin- 847105");

            //start
            Font font1 = new Font(Font.FontFamily.TIMES_ROMAN, 20, Font.BOLD);
            Chunk nameOfShop = new Chunk("                            NAVEEN  MEDICAL  HALL", font1);

            System.err.println("data " + data);

            // creation of the document with a certain size and certain margins
            Document document = new Document(PageSize.A4, 20, 20, 20, 20);
            // creating table and set the column width
            // Hii

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/y   hh:mm:ss a");
            Date thisDate = new Date();

            System.out.println(dateFormat.format(thisDate));
            String d = dateFormat.format(thisDate);
            paragraphFor_Date_and_Time.add(d+"\n......................................................................................................................................................................");
            //Border
            
            Rectangle rectangle_Border = new Rectangle(577, 825, 18, 15);
            
            rectangle_Border.setBorder(Rectangle.BOX);
            rectangle_Border.setBorderWidth(1);
            
            
            

            
            //end_border

            //byy
            PdfPTable table = new PdfPTable(6);
            table.spacingBefore();
            float widths[] = {1, 3, 2, 2, 2, 4};
            table.setWidths(widths);
            table.setHeaderRows(1);

            // add cell of table - header cell
            PdfPCell cell = new PdfPCell(new Phrase("SL-No:"));
            cell.setBackgroundColor(new BaseColor(0, 173, 239));
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("MDICINE NAME"));
            cell.setBackgroundColor(new BaseColor(0, 173, 239));
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("COUNT"));
            cell.setBackgroundColor(new BaseColor(0, 173, 239));
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("EACH PILL PRICE"));
            cell.setBackgroundColor(new BaseColor(0, 173, 239));
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("TOTAL FOR EACH MEDICINE"));
            cell.setBackgroundColor(new BaseColor(0, 173, 239));
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("DIRECTION"));
            cell.setBackgroundColor(new BaseColor(0, 173, 239));
            table.addCell(cell);
            Phrase ph;

            for (int bill = 0; bill < data.size(); bill++) {

                cell = new PdfPCell();
                ph = new Phrase(" " + data.get(bill).getId());
                cell.addElement(ph);
                table.addCell(cell);

                cell = new PdfPCell();
                ph = new Phrase("" + data.get(bill).getMedicineName());
                cell.addElement(ph);
                table.addCell(cell);

                cell = new PdfPCell();
                ph = new Phrase("" + data.get(bill).getCount());
                cell.addElement(ph);
                table.addCell(cell);

                cell = new PdfPCell();
                ph = new Phrase("" + data.get(bill).getEachPillPrice());
                cell.addElement(ph);
                table.addCell(cell);

                cell = new PdfPCell();
                ph = new Phrase("" + data.get(bill).getTotalForEachMedicine());
                cell.addElement(ph);
                table.addCell(cell);

                cell = new PdfPCell();
                ph = new Phrase("" + data.get(bill).getDirection());
                cell.addElement(ph);
                table.addCell(cell);

            }

            PdfWriter.getInstance(document, new FileOutputStream("Slip.pdf"));
            document.open();
            //start
            document.add(paragraphFor_HeadingSpace);
            document.add(nameOfShop);
            
            //end
            document.add(paragraphOfAddress);
            document.add(paagraphWhichWillStoreDoctoreAndPatientName);
            document.add(paragraphFor_Date_and_Time);
            document.add(paragraph2For_TableSpace);

            paragraphOfAddress.spacingAfter();
            document.addCreationDate();

            document.add(table);
       
            document.add(rectangle_Border);
            document.close();
            System.out.println("Successfull.");
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
