/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author mdsad
 */
public class MySQL_Coonection {

    static Connection conn = null;


    private MySQL_Coonection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/stp", "root", "456951357");
        System.err.println("" + conn);

    }

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        if (conn == null) {
            System.err.println("call for getting coonection of db");
            MySQL_Coonection mySQL_Coonection = new MySQL_Coonection();
            return conn;
        } else {
            System.err.println("call for getting coonection of db");
            return conn;
        }

    }

}
