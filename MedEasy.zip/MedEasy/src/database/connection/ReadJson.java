/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database.connection;

import database.connection.MySQL_Coonection;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author mdsad
 */
public class ReadJson {
    public static void main(String[] args) throws FileNotFoundException, IOException, ParseException, ClassNotFoundException, SQLException{
         JSONParser jsonParser = new JSONParser();
         
        try (FileReader reader = new FileReader("C:\\Users\\mdsad\\Downloads\\data\\medicine\\drugs.json"))
        {
            //Read JSON file
            JSONObject obj = (JSONObject) jsonParser.parse(reader);
           JSONArray data=(JSONArray)obj.get("drugs");
          
            for(int i=0;i<data.size();i++){
                 String drugName=data.get(i).toString();
                 System.err.println("data: "+drugName);
                 InsertDataIntoDb(drugName);
            }
                
            }
          
    }

    private static void InsertDataIntoDb(String drugName) throws ClassNotFoundException, SQLException {
       Connection connect=MySQL_Coonection.getConnection();
       PreparedStatement insertstremment=connect.prepareStatement("insert into drugs(medicine_name) values(?)");
       insertstremment.setString(1, drugName);
       insertstremment.executeUpdate();  
    }
}
